const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const db = new Database('zelva.db');
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- INIT DB ---
db.exec(`
  CREATE TABLE IF NOT EXISTS chicas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
  );
  CREATE TABLE IF NOT EXISTS servicios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    precio_ef REAL DEFAULT 0,
    precio_tr REAL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS turnos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chica TEXT NOT NULL,
    clienta TEXT NOT NULL,
    servicio TEXT NOT NULL,
    precio_ef REAL NOT NULL,
    precio_tr REAL NOT NULL,
    cobrado REAL NOT NULL,
    pago TEXT NOT NULL,
    fecha TEXT NOT NULL,
    obs TEXT DEFAULT '',
    creado_at TEXT DEFAULT (datetime('now','localtime'))
  );
`);

// Seed default data if empty
const chicaCount = db.prepare('SELECT COUNT(*) as n FROM chicas').get();
if (chicaCount.n === 0) {
  const ins = db.prepare('INSERT INTO chicas (nombre) VALUES (?)');
  ['Shan','Valentina','Lucía','Camila','Micaela'].forEach(n => ins.run(n));
}
const srvCount = db.prepare('SELECT COUNT(*) as n FROM servicios').get();
if (srvCount.n === 0) {
  const ins = db.prepare('INSERT INTO servicios (nombre, precio_ef, precio_tr) VALUES (?,?,?)');
  [
    ['Manicura esmaltado común', 3500, 4000],
    ['Manicura semipermanente', 5500, 6200],
    ['Uñas gel manos', 9000, 10000],
    ['Uñas acrílicas manos', 11000, 12500],
    ['Pedicura esmaltado común', 4000, 4500],
    ['Pedicura semipermanente', 6500, 7300],
    ['Lifting de pestañas', 8000, 9000],
    ['Extensiones volumen', 14000, 16000],
    ['Diseño de cejas', 3000, 3400],
    ['Cejas laminadas', 6000, 6800],
  ].forEach(r => ins.run(...r));
}

// --- CHICAS ---
app.get('/api/chicas', (req, res) => {
  res.json(db.prepare('SELECT * FROM chicas ORDER BY nombre').all());
});
app.post('/api/chicas', (req, res) => {
  const { nombre } = req.body;
  if (!nombre) return res.status(400).json({ error: 'Falta nombre' });
  try {
    const r = db.prepare('INSERT INTO chicas (nombre) VALUES (?)').run(nombre);
    res.json({ id: r.lastInsertRowid, nombre });
  } catch { res.status(409).json({ error: 'Ya existe' }); }
});
app.delete('/api/chicas/:id', (req, res) => {
  db.prepare('DELETE FROM chicas WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// --- SERVICIOS ---
app.get('/api/servicios', (req, res) => {
  res.json(db.prepare('SELECT * FROM servicios ORDER BY nombre').all());
});
app.post('/api/servicios', (req, res) => {
  const { nombre, precio_ef, precio_tr } = req.body;
  if (!nombre) return res.status(400).json({ error: 'Falta nombre' });
  const r = db.prepare('INSERT INTO servicios (nombre, precio_ef, precio_tr) VALUES (?,?,?)').run(nombre, precio_ef||0, precio_tr||precio_ef||0);
  res.json({ id: r.lastInsertRowid, nombre, precio_ef, precio_tr });
});
app.delete('/api/servicios/:id', (req, res) => {
  db.prepare('DELETE FROM servicios WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// --- TURNOS ---
app.get('/api/turnos', (req, res) => {
  const { desde, hasta } = req.query;
  let q = 'SELECT * FROM turnos';
  const params = [];
  if (desde && hasta) { q += ' WHERE fecha BETWEEN ? AND ?'; params.push(desde, hasta); }
  else if (desde) { q += ' WHERE fecha >= ?'; params.push(desde); }
  q += ' ORDER BY creado_at DESC';
  res.json(db.prepare(q).all(...params));
});
app.post('/api/turnos', (req, res) => {
  const { chica, clienta, servicio, precio_ef, precio_tr, cobrado, pago, fecha, obs } = req.body;
  if (!chica || !clienta || !servicio || !precio_ef) return res.status(400).json({ error: 'Faltan campos' });
  const r = db.prepare('INSERT INTO turnos (chica,clienta,servicio,precio_ef,precio_tr,cobrado,pago,fecha,obs) VALUES (?,?,?,?,?,?,?,?,?)').run(chica, clienta, servicio, precio_ef, precio_tr||precio_ef, cobrado||precio_ef, pago||'efectivo', fecha, obs||'');
  res.json({ id: r.lastInsertRowid });
});
app.delete('/api/turnos/:id', (req, res) => {
  db.prepare('DELETE FROM turnos WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// --- RESUMEN ---
app.get('/api/resumen', (req, res) => {
  const { desde, hasta } = req.query;
  let where = '';
  const params = [];
  if (desde && hasta) { where = 'WHERE fecha BETWEEN ? AND ?'; params.push(desde, hasta); }
  else if (desde) { where = 'WHERE fecha >= ?'; params.push(desde); }

  const totales = db.prepare(`SELECT COUNT(*) as turnos, SUM(cobrado) as cobrado, SUM(precio_ef) as base_ef, SUM(CASE WHEN pago='efectivo' THEN cobrado ELSE 0 END) as ef, SUM(CASE WHEN pago='transferencia' THEN cobrado ELSE 0 END) as tr FROM turnos ${where}`).get(...params);
  const porChica = db.prepare(`SELECT chica, COUNT(*) as turnos, SUM(precio_ef) as base_ef, SUM(cobrado) as cobrado FROM turnos ${where} GROUP BY chica`).all(...params);
  const COM = 0.37;
  res.json({
    turnos: totales.turnos || 0,
    cobrado: totales.cobrado || 0,
    comisiones: (totales.base_ef || 0) * COM,
    salon: (totales.cobrado || 0) - (totales.base_ef || 0) * COM,
    efectivo: totales.ef || 0,
    transferencia: totales.tr || 0,
    porChica: porChica.map(c => ({ ...c, comision: c.base_ef * COM }))
  });
});

app.listen(PORT, () => console.log(`Zelva Beauty corriendo en puerto ${PORT}`));
